MazeGame Tutorial
2020 Drake Williams
CC BY-SA 4.0 licensed

A simple maze game with 
the goal of staying alive
long enough to beat your old
high score.

This is intended to be a
tutorial for new coders
on the components of a 
fully functional game
and demonstrate some of the
PixelVision 8 APIs in the 
process.

All of the game logic is in
code.lua, and uses under 400
lines of code, including
comments.