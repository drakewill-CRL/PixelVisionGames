-- Maze Game.
-- A PixelVision 8 game by Drake Williams
-- CC BY-SA 4.0 Licensed.

-- We give ourselves a variable to help us track down issues and display internal info during gameplay
-- set this to false for a release, set to true when debugging without a debugger attached.
local debugDisplay = false

-- Game state flags.
local gameRunning = true -- Simple flag to tell if the game is actively running, or if we're on the game over screen.
local gamePaused = false -- is the game paused. Resumes the gameplay loop when false.
local isTitleScreen = true -- we are at the title screen. True because we start at the title screen
local isScrollingToGameplay = false -- for the scroll from the title screen to the maze.
local titleTextColorShift = 1 -- Which color the title screen currently draws tiles in.
local frameCounter = 0 -- every call, update this instead of counting based on timeDelta

-- Score is seconds of active gameplay, but we will hold milliseconds here and display seconds
-- in the Draw function.
local score = 0

-- We will also save the highest score to the cart, and declare a variable here for it in memory
local highScore = 0

-- The player object and all of the values we need to track specific to them.
-- Actual values are declared in Init(), this is set to make it accessible globally
local player = {}

-- Enemies have pretty much the same information to track as the player.
local enemy1 = {}
local enemy2 = {}
local enemy3 = {}

local lastAngle = 0 -- value used for debugging enemy AI

-- The Init() method is part of the game's lifecycle and called a game starts.
function Init()
    BackgroundColor(0)
    PlaySong(0, false)

    -- Load our saved high score data, or 0 if there isnt any.
    highScore = ReadSaveData("highscore", "0")

    -- set the camera position to the title screen, which is to the right of the main gameplay maze in the tilemap.
    ScrollPosition(256, 0)

    -- Declare a lot of initialization here
    --some of this is redundant, because we just re-call Init to restart the game
    score = 0
    isTitleScreen = true
    gameRunning = true

    player.xTile = 1 -- tile is the space they player is in. Starts in the upper-right corner.
    player.yTile = 1
    player.xOffset = 0 -- invididual pixels to shift them in their tile for animation purposes.
    player.yOffset = 0
    player.facing = 0 -- 0 is up, 1 is right, 2 id down, 3 is left.

    enemy1.xTile = 30 -- starts in the lower-right corner
    enemy1.yTile = 28
    enemy1.xOffset = 0
    enemy1.yOffset = 0
    enemy1.facing = 0 -- facing will do double-duty in the AI logic

    enemy2.xTile = 1 -- starts in the lower-left corner
    enemy2.yTile = 28
    enemy2.xOffset = 0
    enemy2.yOffset = 0
    enemy2.facing = 0 -- facing will do double-duty in the AI logic

    enemy3.xTile = 30 -- starts in the upper-right corner
    enemy3.yTile = 1
    enemy3.xOffset = 0
    enemy3.yOffset = 0
    enemy3.facing = 0 -- facing will do double-duty in the AI logic

end

--[[
  The Update() method is part of the game's life cycle. The engine calls
  Update() on every frame before the Draw() method. It accepts one argument,
  timeDelta, which is the difference in milliseconds since the last frame.
]] --
function Update(timeDelta)
    if (isTitleScreen) then
        UpdateTitleScreen() -- handles logic for the title screen stage of the game.
    elseif (isScrollingToGameplay) then
        UpdateScrollingToGame()
    else
        UpdateGameplay(timeDelta)

    end -- end titlescreen/scrolling/gameplay else
end -- end Update function

--[[
  The Draw() method is part of the game's life cycle. It is called after
  Update() and is where all of our draw calls should go. We'll be using this
  to render sprites to the display.
]] --
function Draw()
    if (isTitleScreen) then
        DrawTitleScreen()
    elseif (isScrollingToGameplay) then
        DrawScrollingToGame()
    else
        DrawGameplay()
    end ---titlescreen/scrollling/gameplay if
end -- Draw

function PlayerInput()
    -- move 1 pixel per update call. This ignores timeDelta for simpicity.
    -- NOTE: this means that the player could theoretically get a higher score on 
    -- a computer running at less than 60 FPS, like a Raspberry Pi 4 or
    -- a system with background tasks using 100% of the CPU.

    -- Check in here first to see if we're toggling the paused state.
    if (Button(Buttons.Start, InputState.Released)) then
        gamePaused = not gamePaused
    end

    -- If we are paused, don't let the player move.
    if (not gamePaused) then
        if (Button(Buttons.Up, InputState.Down)) then -- player is pushing DOWN
            -- change facing whether character can move that direction or not, so the player
            -- can see that their input was taken.
            player.facing = 0
            -- if Offset is > 0, we're moving INTO our current tile, use it
            -- if Offset is < 0, we're moving OUT out of our tile, use the one to the side
            if (player.yOffset > 0) then
                tileInfo = Tile(player.xTile, math.max(0, player.yTile))
            else
                tileInfo = Tile(player.xTile, math.max(0, player.yTile - 1))
            end

            -- Tile ID 0 is the fully empty space, and the only one in the tilemap we can move through
            -- Every other tile ID is a wall. This logic allows us to avoid using the flag layer
            -- of the tilemap for navigation purposes, though we still check flag 0 (Intersection)
            -- to determine when to change directions.
            if (tileInfo.spriteID == 0) then
                if (player.xOffset == 0) then -- player can only move if they're in the center of the tile OR already moving on this axis,
                    player.yOffset = player.yOffset - 1 -- move 1 pixel in the pushed direction.
                    if (player.yOffset == -5) then -- if you've crossed the center line, change which tile you're in and reverse the offset to be at the far side of it.
                        player.yTile = player.yTile - 1
                        player.yOffset = 4
                    end
                end
            end
        end

        -- repeat the same logic for each other direction, adjusting signs and axes.
        if (Button(Buttons.Right, InputState.Down)) then
            player.facing = 1
            if (player.xOffset < 0) then
                tileInfo = Tile(math.min(player.xTile, 31), player.yTile)
            else
                tileInfo = Tile(math.min(player.xTile + 1, 31), player.yTile)
            end
            if (tileInfo.spriteID == 0) then
                if (player.yOffset == 0) then
                    player.xOffset = player.xOffset + 1
                    if (player.xOffset == 5) then
                        player.xTile = player.xTile + 1
                        player.xOffset = -4
                    end
                end
            end
        end

        if (Button(Buttons.Down, InputState.Down)) then
            player.facing = 2
            if (player.yOffset < 0) then
                tileInfo = Tile(player.xTile, math.max(0, player.yTile))
            else
                tileInfo = Tile(player.xTile, math.min(30, player.yTile + 1))
            end

            if (tileInfo.spriteID == 0) then
                if (player.xOffset == 0) then
                    player.yOffset = player.yOffset + 1
                    if (player.yOffset == 5) then
                        player.yTile = player.yTile + 1
                        player.yOffset = -4
                    end
                end
            end
        end

        if (Button(Buttons.Left, InputState.Down)) then
            player.facing = 3
            if (player.xOffset > 0) then
                tileInfo = Tile(math.max(player.xTile, 0), player.yTile)
            else
                tileInfo = Tile(math.max(player.xTile - 1, 0), player.yTile)
            end
            if (tileInfo.spriteID == 0) then
                if (player.yOffset == 0) then
                    player.xOffset = player.xOffset - 1
                    if (player.xOffset == -5) then
                        player.xTile = player.xTile - 1
                        player.xOffset = 4
                    end
                end
            end
        end

    end -- if notPaused 
end -- end PlayerInput function

function AI(enemy, targetLoc)
    -- Enemy 1 AI: Move to the player's location via closest possible path.
    -- pathfind on every intersection (determined via Flag1 being set on our current tile.)
    local tileInfo = Tile(enemy.xTile, enemy.yTile)
    if (enemy.xOffset == 0 and enemy.yOffset == 0 and tileInfo.flag == 1) then
        -- In the center of a tile. Run pathfinding against the player's current location to get a direction
        -- and move in that direction 1 pixel
        setFacing(enemy, targetLoc)
    end

    -- we have our facing, either from this turn or from a previous one. Move in that direction.
    -- Not in the center of a tile, keep moving in the same direction.
    if enemy.facing == 0 then
        -- Move up. Same rules for positioning as the player.
        enemy.yOffset = enemy.yOffset - 1
        if (enemy.yOffset == -5) then
            enemy.yTile = enemy.yTile - 1
            enemy.yOffset = 4
        end
    end

    if enemy.facing == 1 then
        -- right
        enemy.xOffset = enemy.xOffset + 1
        if (enemy.xOffset == 5) then
            enemy.xTile = enemy.xTile + 1
            enemy.xOffset = -4
        end
    end

    if enemy.facing == 2 then
        -- down
        enemy.yOffset = enemy.yOffset + 1
        if (enemy.yOffset == 5) then
            enemy.yTile = enemy.yTile + 1
            enemy.yOffset = -4
        end
    end

    if enemy.facing == 3 then
        -- left
        enemy.xOffset = enemy.xOffset - 1
        if (enemy.xOffset == -5) then
            enemy.xTile = enemy.xTile - 1
            enemy.xOffset = 4
        end
    end

end -- end AI function

function setFacing(enemy, targetTile)
    -- Get the angle to the desired point, then try to move in that direction
    -- if that direction isn't passable, try then 
    -- Loops clockwise if the desired direction is unavailable.
    local xDist = targetTile.xTile - enemy.xTile
    local yDist = targetTile.yTile - enemy.yTile
    local angleBetween = math.deg(math.atan(yDist / xDist))
    -- angleBetween is a range from -180 to 180, with 0 being down and higher numbers going counter-clockwise

    --a directional correction check
    if (enemy.xTile < targetTile.xTile) then
        angleBetween = angleBetween + 90
    else
        angleBetween = angleBetween - 90
    end

    -- don't let enemies turn back and forth in the same direction each intersection
    local bannedFacing = enemy.facing
    if (bannedFacing == 0) then
        bannedFacing = 2
    elseif (bannedFacing == 1) then
        bannedFacing = 3
    elseif (bannedFacing == 2) then
        bannedFacing = 0
    elseif (bannedFacing == 3) then
        bannedFacing = 1
    end

    -- shortcut rules:
    -- if angle is negative, go left
    -- if angle is positive, go right
    -- if abs(angle) is over 90, go down
    -- if abs(angle) is under 90, go up
    -- BUT don't pick the opposite direction of our current facing.
    local secondaryFacing = 0
    if (angleBetween > 0 or angleBetween == 90) then
        enemy.facing = 1 -- RIGHT
    elseif (angleBetween < 0 or angleBetween == -90) then
        enemy.facing = 3 -- LEFT
    end

    if (angleBetween ~= -180 and
        (math.abs(angleBetween) > 90 or angleBetween == 0)) then
        secondaryFacing = enemy.facing
        enemy.facing = 2 -- DOWN
    elseif (math.abs(angleBetween) < 90 or angleBetween == -180) then
        secondaryFacing = enemy.facing
        enemy.facing = 0 -- UP
    end
    lastAngle = angleBetween -- for debugging view

    local tileInfo
    local canMove = false
    -- if the space the AI wants to move into is a wall, don't move there
    while not canMove do
        if (enemy.facing == 0) then -- Up
            tileInfo = Tile(enemy.xTile, enemy.yTile - 1)
            if (tileInfo.spriteID ~= 0 or bannedFacing == enemy.facing) then
                if (secondaryFacing > 0) then
                    enemy.facing = secondaryFacing
                    secondaryFacing = -1
                else
                    enemy.facing = 1
                end
            else
                canMove = true
            end
        end

        if (enemy.facing == 1) then -- right
            tileInfo = Tile(enemy.xTile + 1, enemy.yTile)
            if (tileInfo.spriteID ~= 0 or bannedFacing == enemy.facing) then
                if (secondaryFacing > 0) then
                    enemy.facing = secondaryFacing
                    secondaryFacing = -1
                else
                    enemy.facing = 2
                end
            else
                canMove = true
            end
        end

        if (enemy.facing == 2) then -- down
            tileInfo = Tile(enemy.xTile, enemy.yTile + 1)
            if (tileInfo.spriteID ~= 0) or bannedFacing == enemy.facing then
                if (secondaryFacing > 0) then
                    enemy.facing = secondaryFacing
                    secondaryFacing = -1
                else
                    enemy.facing = 3
                end
            else
                canMove = true
            end
        end

        if (enemy.facing == 3) then -- left
            tileInfo = Tile(enemy.xTile - 1, enemy.yTile)
            if (tileInfo.spriteID ~= 0 or bannedFacing == enemy.facing) then
                if (secondaryFacing > 0) then
                    enemy.facing = secondaryFacing
                    secondaryFacing = -1
                else
                    enemy.facing = 0
                end
            else
                canMove = true
            end
        end

    end -- while not CanMove
end -- setFacing

function UpdateTitleScreen()
    if (Button(Buttons.Start, InputState.Released)) then
        isTitleScreen = false
        isScrollingToGameplay = true
    end

    frameCounter = frameCounter + 1
    if (frameCounter >= 60) then
        frameCounter = 0
        titleTextColorShift = titleTextColorShift + 1
        if (titleTextColorShift > 16) then titleTextColorShift = 1 end
    end
end

function UpdateScrollingToGame()
    -- Nothing actually happens here, but if we wanted it to, the function exists.
end

function UpdateGameplay(timeDelta)
    -- Game logic order:
    -- check current gameover state.
    -- Handle player input
    -- handle AI movement and score calculation
    -- Detect collisions to set gameover state.

    -- Step 1: Game Over logic. Gets set false after the AI moves into the player's tile.
    if (not gameRunning) then return end

    -- Step 2: Player Input. Long blocks of logic should be in their own functions.
    PlayerInput()
    --We will do a game over check after the player moves in addition to when the AI moves
    --to avoid a case where the player could move into an enemy the same frame they move out
    --of that tile and pass through each other.
    GameOverCheck()

    -- Step 3: AI Logic. Also its own function.
    -- Score is tracked here as time. Each second alive is one point. Add timeDelta to our current score
    if (not gamePaused) then -- don't increment score or move the AI if we're paused.
        score = score + timeDelta

        local AI1Target = player -- Homes in on the player
        AI(enemy1, AI1Target)

        local AI2Target = {} -- sneaks up behind the player.
        if (player.facing == 0) then
            AI2Target.xTile = Clamp(player.xTile, 1, 30)
            AI2Target.yTile = Clamp(player.yTile + 4, 1, 28)
        elseif (player.facing == 1) then
            AI2Target.xTile = Clamp(player.xTile - 4, 1, 30)
            AI2Target.yTile = Clamp(player.yTile, 1, 28)
        elseif (player.facing == 2) then
            AI2Target.xTile = Clamp(player.xTile, 1, 30)
            AI2Target.yTile = Clamp(player.yTile - 4, 1, 28)
        elseif (player.facing == 3) then
            AI2Target.xTile = Clamp(player.xTile + 4, 1, 30)
            AI2Target.yTile = Clamp(player.yTile, 1, 28)
        end
        AI(enemy2, AI2Target)

        local AI3Target = {} -- aims in front of the player
        if (player.facing == 0) then
            AI3Target.xTile = Clamp(player.xTile, 1, 30)
            AI3Target.yTile = Clamp(player.yTile - 4, 1, 28)
        elseif (player.facing == 1) then
            AI3Target.xTile = Clamp(player.xTile + 4, 1, 30)
            AI3Target.yTile = Clamp(player.yTile, 1, 28)
        elseif (player.facing == 2) then
            AI3Target.xTile = Clamp(player.xTile, 1, 30)
            AI3Target.yTile = Clamp(player.yTile + 4, 1, 28)
        elseif (player.facing == 3) then
            AI3Target.xTile = Clamp(player.xTile - 4, 1, 30)
            AI3Target.yTile = Clamp(player.yTile, 1, 28)
        end
        AI(enemy3, AI3Target)
    end

    -- Step 4: Collision checks. If an enemy is in the player's tile, the player loses.
    GameOverCheck()
end

function GameOverCheck()
    
    if ((enemy1.xTile == player.xTile and enemy1.yTile == player.yTile) or
        (enemy2.xTile == player.xTile and enemy2.yTile == player.yTile) or
        (enemy3.xTile == player.xTile and enemy3.yTile == player.yTile)) then
        -- game over.
        gameRunning = false;
        PlaySong(1, false) --play the sad music
        -- save high score, if we beat the old one.
        if math.floor(score / 1000) > tonumber(highScore) then
            highScore = math.floor(score / 1000)
            WriteSaveData("highscore", highScore)
        end
    end -- collision checks if
end

function DrawTitleScreen()
    RedrawDisplay()
    DrawText("By Drake Williams", 60, 152, DrawMode.Sprite, "large",
             titleTextColorShift)
    DrawText("(CC BY-SA 4.0)", 76, 168, DrawMode.Sprite, "large",
             titleTextColorShift)
end

function DrawScrollingToGame()
    local point = ScrollPosition()
    ScrollPosition(point.x - 1, 0)
    RedrawDisplay()
    if (point.x == 1) then isScrollingToGameplay = false; end
end

function DrawGameplay()
    -- We can use the RedrawDisplay() method to clear the screen and redraw
    -- the tilemap in a single call.
    RedrawDisplay() -- Draws the maze from tilemap.json automatically

    -- The player sprites are arranged so that adding player.facing to the first sprite's ID 
    -- will draw the correct sprite to show which way the player wanted to move.
    DrawSprite(20 + player.facing, (player.xTile * 8) + player.xOffset,
               (player.yTile * 8) + player.yOffset)

    -- Enemy does the same.
    DrawSprite(32 + enemy1.facing, (enemy1.xTile * 8) + enemy1.xOffset,
               (enemy1.yTile * 8) + enemy1.yOffset)
    DrawSprite(32 + enemy2.facing, (enemy2.xTile * 8) + enemy2.xOffset,
               (enemy2.yTile * 8) + enemy2.yOffset, false, false,
               DrawMode.Sprite, 1)
    DrawSprite(32 + enemy3.facing, (enemy3.xTile * 8) + enemy3.xOffset,
               (enemy3.yTile * 8) + enemy3.yOffset, false, false,
               DrawMode.Sprite, 2)

    if (not gameRunning) then
        DrawText("Game Over", 88, 120, DrawMode.Sprite, "large", 6)
        DrawText("Press Start To Try Again", 32, 128, DrawMode.Sprite, "large", 6)
        if (Button(Buttons.Start, InputState.Released)) then
            Init()
        end
    end

    -- 1 second is one point, but score is measured in milliseconds alive.
    -- So here we divide that to get whole seconds.
    DrawText("Score: " .. math.floor(score / 1000), 0, 250, DrawMode.Sprite,
             "large", 6)
    DrawText("Best: " .. math.floor(highScore), 128, 250, DrawMode.Sprite,
             "large", 6)

    -- here, we check if we have our debug value set, and if so to display some precise position info on the player.
    if (debugDisplay) then
        DrawText("Last Angle Detected:" .. lastAngle, 0, 176, DrawMode.Sprite,
                 "large", 4)

        DrawText("Player X:" .. player.xTile .. ", " .. player.xOffset, 0, 200,
                 DrawMode.Sprite, "large", 4)
        DrawText("Player Y:" .. player.yTile .. ", " .. player.yOffset, 0, 208,
                 DrawMode.Sprite, "large", 4)

        DrawText("Enemy X:" .. enemy1.xTile .. ", " .. enemy1.xOffset, 0, 216,
                 DrawMode.Sprite, "large", 4)
        DrawText("Enemy Y:" .. enemy1.yTile .. ", " .. enemy1.yOffset, 0, 224,
                 DrawMode.Sprite, "large", 4)
    end
end
